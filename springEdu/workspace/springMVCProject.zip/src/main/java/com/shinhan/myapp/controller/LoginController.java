package com.shinhan.myapp.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.firstzone.myapp.emp.EmpDTO;
import org.firstzone.myapp.emp.EmpService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/auth")
public class LoginController {
	
	@Autowired
	EmpService eService;
	
	Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	
	@GetMapping("/login.do")
	public void loginDisplay() {
		logger.debug("login.do��û(debug)");
		logger.debug("login.do��û(info)");
		logger.debug("login.do��û(warn)");
		logger.debug("login.do��û(error)");
	}
	
	@GetMapping("/logout.do")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:login.do";
	}
	
	@PostMapping("/login.do")
	public String loginCheck(@RequestParam("email") String email,
			@RequestParam("pswd") String phone,
			HttpSession session,
			HttpServletRequest request) {
		
		//mybatis�� ����/ JDBC������ �������� �ʴ� id�� -1, Ʋ�� pw�� -2
		
		EmpDTO emp = eService.loginCheck(email, phone);
		if(emp.getEmployee_id() ==-1) {
			session.setAttribute("loginResult", "�������� �ʴ� ID�Դϴ�.");
			return "redirect:login.do";
		}else if(emp.getEmployee_id() ==-2) {
			session.setAttribute("loginResult", "��й�ȣ�� Ʋ�Ƚ��ϴ�.");
			return "redirect:login.do";
		}else {
			//�α��μ���
			session.setAttribute("loginResult", "�α��� ����.");
			session.setAttribute("emp", emp);
			
			String lastRequest = (String)session.getAttribute("lastRequest");
			String queryString = (String)session.getAttribute("queryString");
			String goPage;
			if(lastRequest == null) {
				goPage = "../index.do";
			}else {
				//�α��� ���� �ٸ� �������� ��û
				int length = request.getContextPath().length();
				goPage = lastRequest.substring(length);
				if(queryString!=null) goPage = goPage + "?" + queryString;
			}

			return "redirect:" + goPage;
		}
		
	}

}
