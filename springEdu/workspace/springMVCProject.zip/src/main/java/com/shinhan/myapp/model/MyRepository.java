package com.shinhan.myapp.model;

import org.springframework.stereotype.Repository;

@Repository
public class MyRepository {

}
