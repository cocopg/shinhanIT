package com.shinhan.myapp.model;

import org.springframework.stereotype.Service;

@Service
public class MyService {

}
